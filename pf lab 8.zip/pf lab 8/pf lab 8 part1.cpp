#include<iostream>
using namespace std;
int main()
{


	int z=1,n;
	cout<<"Enter no. of rows for pattern:";
	cin>>n;                                                
    cout<<endl;                                            

                                                              
   for(int i =n; i>=1; i--){  //rows
      
      for(int j=n; j>n-i; j--){ //columns(max.)
      	
      	 cout<<"*";
	}	
     cout<<endl; 	
	  }
	
	

return 0;
}